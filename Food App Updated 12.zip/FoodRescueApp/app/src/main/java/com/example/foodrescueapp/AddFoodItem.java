package com.example.foodrescueapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.foodrescueapp.data.DatabaseHelper;
import com.example.foodrescueapp.model.User;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;

public class AddFoodItem extends AppCompatActivity {

    EditText foodTitleInp;
    EditText foodDescInp;
    EditText foodPickupInp;
    EditText foodLocInp;
    EditText foodQntInp;
    Button saveFoodButton;
    CalendarView calendarView;
    ImageButton addImageButton;
    ImageView foodImageView;
    DatabaseHelper db;
    Uri ImageURL;
    Bitmap bitmap;
    private static final int PICK_IMAGE_CODE = 1000;
    private static final int PERMISSION_CODE = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_new_food_item);
        foodTitleInp = findViewById(R.id.foodTitleInp);
        foodQntInp = findViewById(R.id.foodQntInp);
        saveFoodButton = findViewById(R.id.saveFoodButton);
        foodLocInp = findViewById(R.id.foodLocInp);
        foodPickupInp = findViewById(R.id.foodPickupInp);
        calendarView = findViewById(R.id.calendarView);
        foodDescInp = findViewById(R.id.foodDescInp);
        addImageButton = findViewById(R.id.addImageButton);
        foodImageView = findViewById(R.id.foodImageView);
        db = new DatabaseHelper(AddFoodItem.this);


        saveFoodButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap1 = bitmap;
                byte[] byteArray = null;
                if (bitmap1 != null){
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap1.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byteArray = stream.toByteArray();
                }
                long result = db.insertFood(new Food(foodTitleInp.getText().toString(), foodDescInp.getText().toString(),foodPickupInp.getText().toString(),Long.toString(calendarView.getDate()),foodLocInp.getText().toString(),byteArray,foodQntInp.getText().toString()));
                if(result>0){
                    Toast.makeText(getApplicationContext(),"Food added Successfully!",Toast.LENGTH_LONG).show();

                }
            }
        });

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permissions, PERMISSION_CODE);
                    }
                    else{
                        pickImageFromGallery();
                    }

                }
                else{
                    pickImageFromGallery();
                }
            }
        });
    }

    private void pickImageFromGallery() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, PICK_IMAGE_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImageFromGallery();
                } else {
                    Toast.makeText(this, "Permission denied!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE_CODE) {
            Uri imageUri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),imageUri);
                foodImageView.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }

            //foodImageView.setImageURI(data.getData());
            ImageURL = data.getData();
            addImageButton.setVisibility(View.GONE);
        }
    }
}