package com.example.foodrescueapp;

import java.util.Date;

public class Food {


    public String food_title, food_desc, pickup_times, location,quantity,date;
    public byte[] food_imageID;
    public int id;

    public Food(String food_title, String food_desc, String pickup_times, String date, String location, byte[] food_imageID, String quantity)
    {
        this.food_title = food_title;
        this.food_desc = food_desc;
        this.pickup_times = pickup_times;
        this.location = location;
        this.food_imageID = food_imageID;
        this.quantity = quantity;
        this.date = date;
    }
    public Food(String food_title, String food_desc, byte[] food_imageID)
    {
        this.food_title = food_title;
        this.food_desc = food_desc;
        this.food_imageID = food_imageID;
    }
    public Food(String food_title, String food_desc, byte[] food_imageID, int id)
    {
        this.food_title = food_title;
        this.food_desc = food_desc;
        this.food_imageID = food_imageID;
        this.id = id;
    }
    public Food(){}

    public Food(byte[] food_imageID)
    {
        this.food_imageID = food_imageID;
    }

    public String getFood_title() {
        return food_title;
    }

    public void setFood_title(String food_title) {
        this.food_title = food_title;
    }

    public String getFood_desc() {
        return food_desc;
    }

    public void setFood_desc(String food_desc) {
        this.food_desc = food_desc;
    }

    public String getPickup_times() {
        return pickup_times;
    }

    public void setPickup_times(String pickup_times) {
        this.pickup_times = pickup_times;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public byte[] getFood_imageID() {
        return food_imageID;
    }

    public void setFood_imageID(byte[] food_imageID) {
        this.food_imageID = food_imageID;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}