package com.example.foodrescueapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Patterns;

import androidx.appcompat.app.AppCompatActivity;

import com.example.foodrescueapp.data.DatabaseHelper;
import com.example.foodrescueapp.model.User;

import java.util.ArrayList;
import java.util.List;

import kotlin.collections.ArrayDeque;

public class customerSignUp extends AppCompatActivity {
    DatabaseHelper db;

    EditText userName;
    EditText email;
    EditText phoneNo;
    EditText address;
    EditText password;
    EditText confirmPassword;
    Button saveButton;
    List userList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_sign_up);
        userName = findViewById(R.id.userName);
        email = findViewById(R.id.email);
        phoneNo = findViewById(R.id.phoneNo);
        address = findViewById(R.id.address);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);
        saveButton = findViewById(R.id.saveButton);

        db = new DatabaseHelper(customerSignUp.this);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String password1 = password.getText().toString();
                String confirmPassword1 = confirmPassword.getText().toString();
                boolean doesUserExist = db.doesUserExist(userName.getText().toString());
                boolean doesUserEmailExist = db.doesUserEmailExist(email.getText().toString());

                if (userName.getText().toString().isEmpty() || email.getText().toString().isEmpty() || phoneNo.getText().toString().isEmpty() || address.getText().toString().isEmpty() || password.getText().toString().isEmpty() || confirmPassword.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please insert all fields.", Toast.LENGTH_SHORT).show();
                }
                else if (doesUserExist){
                    Toast.makeText(getApplicationContext(), "Username already taken.", Toast.LENGTH_LONG).show();
                }
                else if (doesUserEmailExist){
                    Toast.makeText(getApplicationContext(), "Email already registered.", Toast.LENGTH_LONG).show();
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()){
                    Toast.makeText(getApplicationContext(), "Please enter a valid Email.", Toast.LENGTH_LONG).show();
                }
                else if ((password1.equals(confirmPassword1))) {
                    Toast.makeText(getApplicationContext(), "Signup Successful!", Toast.LENGTH_LONG).show();
                    long result = db.insertUser(new User(userName.getText().toString(), password.getText().toString(), email.getText().toString(), phoneNo.getText().toString(), address.getText().toString()));
                    Intent MainActivity = new Intent(customerSignUp.this, MainActivity.class);
                    startActivity(MainActivity);
                }
                else{
                    Toast.makeText(customerSignUp.this,"Both provided passwords do not match",Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}