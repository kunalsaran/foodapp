package com.example.foodrescueapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.foodrescueapp.data.DatabaseHelper;
import com.example.foodrescueapp.model.User;

public class signUp extends AppCompatActivity {

    DatabaseHelper db;

    EditText userName;
    EditText email;
    EditText phoneNo;
    EditText address;
    EditText password;
    EditText confirmPassword;
    Button saveButton;
    Button adminButton;
    Button salesButton;
    Button customerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        adminButton = findViewById(R.id.adminButton);
        salesButton = findViewById(R.id.salesButton);
        customerButton = findViewById(R.id.customerButton);

        db = new DatabaseHelper(signUp.this);

        salesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sales_sign_up = new Intent(signUp.this, sales_sign_up.class);
                startActivity(sales_sign_up);
            }
        });

        adminButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent adminSign_up = new Intent(signUp.this, adminSign_up.class);
                startActivity(adminSign_up);
            }
        });

        customerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent customerSignUp = new Intent(signUp.this, customerSignUp.class);
                startActivity(customerSignUp);
            }
        });

    }

}