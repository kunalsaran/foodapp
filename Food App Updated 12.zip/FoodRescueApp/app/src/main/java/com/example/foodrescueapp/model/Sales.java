package com.example.foodrescueapp.model;

public class Sales {

    private int user_id2;
    private String username2;
    private String password2;
    private String email2;
    private String phoneNo2;
    private String address2;

    public Sales( String username2, String password2, String email2, String phoneNo2, String address2) {
        this.username2 = username2;
        this.password2 = password2;
        this.email2 = email2;
        this.phoneNo2 = phoneNo2;
        this.address2 = address2;
    }


    public Sales() {
    }

    public int getUser_id2() {
        return user_id2;
    }

    public void setUser_id2(int user_id2) {
        this.user_id2 = user_id2;
    }

    public String getUsername2() {
        return username2;
    }

    public void setUsername2(String username2) {
        this.username2 = username2;
    }

    public String getPassword2() {
        return password2;
    }

    public void setPassword2(String password2) {
        this.password2 = password2;
    }

    public String getEmail2(){
        return  email2;
    }

    public void setEmail2(String email2){
        this.email2 = email2;
    }

    public String getPhoneNo2(){
        return  phoneNo2;
    }

    public void setPhoneNo2(String phoneNo2){
        this.phoneNo2 = phoneNo2;
    }
    public String getAddress2(){
        return  address2;
    }

    public void setAddress2(String address2){
        this.address2 = address2;
    }
}